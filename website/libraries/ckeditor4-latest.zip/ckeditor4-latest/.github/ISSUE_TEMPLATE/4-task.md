---
name: "\U0001F477 Task"
about: It's neither a bug nor feature request.
title: ''
labels: type:task
assignees: ''

---

## Type of report

Task

## Provide description of the task

*What steps should be taken to fulfil the task?*

## Other details

* Browser: …
* OS: …
* CKEditor version: …
* Installed CKEditor plugins: …
