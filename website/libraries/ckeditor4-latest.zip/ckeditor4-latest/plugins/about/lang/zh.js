/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'about', 'zh', {
	copy: 'Copyright &copy; $1. All rights reserved.',
	dlgTitle: '關於 CKEditor 4',
	moreInfo: '關於授權資訊，請參閱我們的網站：'
} );
