/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'basicstyles', 'fr-ca', {
	bold: 'Gras',
	italic: 'Italique',
	strike: 'Barré',
	subscript: 'Indice',
	superscript: 'Exposant',
	underline: 'Souligné'
} );
